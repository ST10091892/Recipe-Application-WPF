﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Recipe_Application_WPF;

namespace Recipe_Application_WPF
{
    /// <summary>
    /// Interaction logic for Display_Recipe.xaml
    /// </summary>
    public partial class Display_Recipe : Window
    {
        List<Recipe> sortedList = new List<Recipe>();
        List<Recipe> filteredList = new List<Recipe>();
        public Display_Recipe()
        {
            InitializeComponent();

            //A foreach loop is used to sort the recipes in alphabetical order.
            sortedList = AddRecipe.listOfRecipes.OrderBy(x => x.Name).ToList();
            foreach (Recipe recipe in sortedList)
            {
                lb_RecipeName.Items.Add(recipe.Name);
                foreach (Ingredients ingredient in recipe.Ingredients)
                {
                    if (!Ingredients_ComboBox.Items.Contains(ingredient.IName))
                    {
                        Ingredients_ComboBox.Items.Add(ingredient.IName);
                    }
                    if (!FoodGroup_ComboBox.Items.Contains(ingredient.IFoodGroup))
                    {
                        FoodGroup_ComboBox.Items.Add(ingredient.IFoodGroup);
                    }
                }
            }
            

        }

        //Method that views the recipes information(Steps and Ingredients), once the user clicks on the recipe name in the listbox.
        private void OnRecipeSelectionChange(object sender, SelectionChangedEventArgs e)
        {
            ///Exception handling to ensure that the listbox is not null
            if (lb_RecipeName.SelectedItem != null)
            {
                Ingredients_ListBox.Items.Clear();
                recipeSteps_ListBox.Items.Clear();
                int index = 0;

                //This will display the information of the selected recipe name.
                foreach (Recipe recipe in sortedList)
                {
                    if (recipe.Name.Equals(lb_RecipeName.SelectedItem.ToString()))
                    {
                        
                        foreach (Ingredients ingredients in recipe.Ingredients)
                        {
                            Ingredients_ListBox.Items.Add((index + 1) + ". Name: " + ingredients.IName + " Calories: " + ingredients.ICalories.ToString() + " Unit: " + ingredients.IUnit + " Quantity: " + ingredients.IQuantity.ToString() + " Food Group: " + ingredients.IFoodGroup.ToString());
                        }
                        foreach (Steps steps in recipe.steps)
                        {
                            recipeSteps_ListBox.Items.Add((index + 1) + ". " + steps.Description);
                        }
                        index++;
                    }
                }
            }
        }

        //This method displays the message box to inform the user how to view the recipes information apon entering this window
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Select a recipe to populate the steps and ingrdients.", "Select Recipe", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ComboBox_Ingredients(object sender, EventArgs e)
        {
            FoodGroup_ComboBox.SelectedIndex = -1;
            CaloriesTextBox.Clear();
        }

        private void ComboBox_FoodGroup(object sender, EventArgs e)
        {
            CaloriesTextBox.Clear();
            Ingredients_ComboBox.SelectedIndex = -1;
        }

        //This method will populate the recipes listbox with the information of the user, when in clicks on the recipe name
        private void PopulateRecipeListBox(List<Recipe> recipelist)
        {
            lb_RecipeName.Items.Clear();
            Ingredients_ListBox.Items.Clear();
            recipeSteps_ListBox.Items.Clear();
            foreach (Recipe recipe in filteredList)
            {
                lb_RecipeName.Items.Add(recipe.Name);
            }
        }

        //This is the method that will allow the user to filter the recipes based on three criterias
        private void OnClickFilterRecipes(object sender, RoutedEventArgs e)
        {
            //Exception that displays am error message too the user, that no fiktering option has been selected.
            int calories = 0;
            if(FoodGroup_ComboBox.SelectedIndex== -1 && Ingredients_ComboBox.SelectedIndex==-1 && String.IsNullOrEmpty(CaloriesTextBox.Text)) {
                MessageBox.Show("Select a filtering option to continue.", "No Filtering Option Selected", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                filteredList = new List<Recipe>();
                if (FoodGroup_ComboBox.SelectedIndex != -1)
                {
                    foreach (Recipe recipe in sortedList)
                    {
                        foreach (Ingredients ingredients in recipe.Ingredients)
                        {
                            if (ingredients.IFoodGroup.Equals(FoodGroup_ComboBox.SelectedItem.ToString()))
                            {
                                filteredList.Add(recipe);
                            }
                        }
                    }

                   PopulateRecipeListBox(filteredList);
                }
                else if (Ingredients_ComboBox.SelectedIndex != -1)
                {
                    foreach (Recipe recipe in sortedList)
                    {
                        foreach (Ingredients ingredients in recipe.Ingredients)
                        {
                            if (ingredients.IName.Equals(Ingredients_ComboBox.SelectedItem.ToString()))
                            {
                                filteredList.Add(recipe);
                            }
                        }
                    }
                    PopulateRecipeListBox(filteredList);
                }
                else
                {
                    if (Int32.TryParse(CaloriesTextBox.Text, out calories))
                    {
                        foreach (Recipe recipe in sortedList)
                        {
                            foreach (Ingredients ingredients in recipe.Ingredients)
                            {
                                if (ingredients.ICalories == calories)
                                {
                                    filteredList.Add(recipe);
                                }
                            }
                        }
                        PopulateRecipeListBox(filteredList);
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid calories amount.", "Invalid calories amount entered", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                } 
            }
        }

        //This click event method will clear all the filtering in the window.
        private void OnClickClearFilter(object sender, RoutedEventArgs e)
        {
            lb_RecipeName.Items.Clear();
            Ingredients_ListBox.Items.Clear();
            recipeSteps_ListBox.Items.Clear();
            FoodGroup_ComboBox.SelectedIndex = -1;
            Ingredients_ComboBox.SelectedIndex = -1;
            CaloriesTextBox.Clear();
            foreach (Recipe recipe in sortedList)
            {
                lb_RecipeName.Items.Add(recipe.Name);
            }
        }

        private void CaloriesTextBox_MouseEnter(object sender, MouseEventArgs e)
        {
            FoodGroup_ComboBox.SelectedIndex = -1;
            Ingredients_ComboBox.SelectedIndex = -1;
        }
    }
}
