﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Recipe_Application_WPF
{
    /// <summary>
    /// Interaction logic for AddRecipe.xaml
    /// </summary>
    public partial class AddRecipe : Window
    {
        List<Ingredients> listOfIngredients = new List<Ingredients>();
        List<Steps> steps = new List<Steps>();
        public static List<Recipe> listOfRecipes= new List<Recipe>();
        Recipe recipe;
        Ingredients _ingredients;
        Steps step;

        public AddRecipe()
        {
            InitializeComponent();
           
            //Food Group types which will be populated in the FoodGroup Combobox
            FoodGroup_ComboBox.Items.Add("Fruit and vegetables");
            FoodGroup_ComboBox.Items.Add("Starchy food");
            FoodGroup_ComboBox.Items.Add("Diary");
            FoodGroup_ComboBox.Items.Add("Protein");
            FoodGroup_ComboBox.Items.Add("Fat");

            
        }

        //Click event method that will populate the Ingredient list everytime the add button is clicked

        private void addIngredientToRecipeButton_Click_1(object sender, RoutedEventArgs e)
        {
            int calories = 0;
            int quantity = 0;

            //Exception Handling that displays an error to ensure the Ingredient details are populated
            if (String.IsNullOrEmpty(IngredientName_TextBox.Text) || String.IsNullOrEmpty(IngredientUnit_TextBox.Text) || FoodGroup_ComboBox.SelectedIndex == -1 ||
                Int32.TryParse(IngredientCalories_TextBox.Text, out calories) == false || Int32.TryParse(IngredientQuantity_TextBox.Text, out quantity) == false){
                MessageBox.Show("Please complete all required fields to add an ingredient!", "All Fields not Completed", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                _ingredients = new Ingredients();
                _ingredients.IName = IngredientName_TextBox.Text;
                _ingredients.ICalories = Int32.Parse(IngredientCalories_TextBox.Text);
                _ingredients.IUnit = IngredientUnit_TextBox.Text;
                _ingredients.IQuantity = Int32.Parse(IngredientQuantity_TextBox.Text);
                _ingredients.IFoodGroup = FoodGroup_ComboBox.SelectedItem.ToString();
                listOfIngredients.Add(_ingredients);
                lb_Ingredients.Items.Add("Name: " + _ingredients.IName + " Calories: " + _ingredients.ICalories.ToString() + " Unit: " + _ingredients.IUnit + " Quantity: " + _ingredients.IQuantity.ToString() + " Food Group: " + _ingredients.IFoodGroup.ToString());

                MessageBox.Show("INGREDIENT HAS BEEEN SUCCESFULLY ADDED!", "INGREDIENTS", MessageBoxButton.OK, MessageBoxImage.Information);

                //Clears the textboxes
                IngredientName_TextBox.Clear();
                IngredientCalories_TextBox.Clear();
                IngredientQuantity_TextBox.Clear();
                IngredientUnit_TextBox.Clear();
                FoodGroup_ComboBox.SelectedIndex = -1;
            }
        }
        
        //Click event method that will add the recipe to the List of Recipes when clicked.
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

            //Exception handling that displays an error to ensure that recipe name is not empty
            if (String.IsNullOrEmpty(RecipeName_TextBox.Text))
            {
                MessageBox.Show("Please enter a recipe name!", "Enter Recipe Name", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if(listOfIngredients.Count == 0)
                {
                    MessageBox.Show("Please add ingredients!", "No ingredients added", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (steps.Count == 0)
                    {
                        MessageBox.Show("Please add steps!", "No added steps", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        recipe = new Recipe();
                        recipe.Name = RecipeName_TextBox.Text;
                        recipe.steps = steps;
                        recipe.Ingredients= listOfIngredients;                      
                        listOfRecipes.Add(recipe);
                        MessageBox.Show("RECIPE HAS BEEEN SUCCESFULLY ADDED!", "Recipe", MessageBoxButton.OK, MessageBoxImage.Information);

                        RecipeName_TextBox.Clear();
                        lb_Ingredients.Items.Clear();
                        steps = new List<Steps>();
                        listOfIngredients = new List<Ingredients>();
                        lb_Steps.Items.Clear();

                    }
                }
            }
        }

        //Event handler for the combo box
        private void ComboBox_FoodGroup(object sender, EventArgs e)
        {
            //Exception handling that displays an error  to ensure that the user selects a food group.
            if (FoodGroup_ComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a food group!", "Select Food Group", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //Click event method that will add a step to the list of steps, everytime the button is clicked.
        private void addStepToRecipeButton_Click_1(object sender, RoutedEventArgs e)
        {

            //Exception Handling that displays an error to ensure that the Steps are not empty.
            if (String.IsNullOrEmpty(RecipeSteps_TextBox.Text))
            {
                MessageBox.Show("Please complete all required fields to add a step!", "All Fields not Completed", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                step = new Steps();
                step.Description = RecipeSteps_TextBox.Text;
                steps.Add(step);
                lb_Steps.Items.Add(RecipeSteps_TextBox.Text);

                MessageBox.Show("STEP HAS BEEEN SUCCESFULLY ADDED!", "STEPS", MessageBoxButton.OK, MessageBoxImage.Information);

                //Clears the textbox

                RecipeSteps_TextBox.Clear();
            }
        }
    }
    public class Recipe
    {
        //Default Constructor
        public Recipe()
        {

        }
        //Properties of the recipe
        public string? Name { get; set; }
        public List<Ingredients> Ingredients;
        public List<Steps> steps;
    }
    public class Ingredients
    {
        //Default Constructor
        public Ingredients()
        {

        }
        //Properties of the Ingredients
        public string? IName { get; set; }
        public int? IQuantity { get; set; }
        public string? IUnit { get; set; }
        public int? ICalories { get; set; }
        public string? IFoodGroup { get; set; }

        
    }
    public class Steps
    {
        //Default Constructor
        public Steps() { }

        //Properties of the steps 
        public string? Description { get; set; }
    }
}
